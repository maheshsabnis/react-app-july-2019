import React, { Component } from 'react';
import './App.css';

import {
  Route,
  Link,
  Switch,
  Redirect
} from 'react-router-dom';

import Home from './components/Home';
import About from './components/About';
import Messages from './components/Messages';

class App extends Component {
  render() {
    return (
      <div className="App">
          <h1>Welcome to React Routing App</h1>
          <table>
          <tbody>
            <tr>
              <td><Link to="/">Home</Link></td>
              <td><Link to="/messages">Messages</Link> </td>
              <td><Link to="/about">About</Link></td>
            </tr>
          </tbody>
        </table>
           
        <div className="App-intro">
          <Switch>
            <Route exact path="/" component={Home} />
            <Route path="/messages" component={Messages} />
            <Route path="/about" component={About} />
            <Redirect to="/" />
          </Switch>
        </div>
      </div>
    );
  }
}

export default App;
