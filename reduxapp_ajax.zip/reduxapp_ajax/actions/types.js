// action types (MUST BE UPPER CASE CONSTANTS)
export const ADD_PRODUCT = "ADD_PRODUCT";
export const LIST_PRODUCTS = "LIST_PRODUCTS";
